package com.example.weioule.recycleryviewdemo;

/**
 * Author by weioule.
 * Date on 2018/8/17.
 */
public class MyBean {
    private String tv;

    public String getTv() {
        return tv;
    }

    public void setTv(String tv) {
        this.tv = tv;
    }
}
